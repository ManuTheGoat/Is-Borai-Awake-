import type { VercelRequest, VercelResponse } from 'vercel';
import { kv } from '@vercel/kv';

// key: 'borai:status'
// value: { status: 'yes'|'no', bedISO?: string, wakeISO?: string, updatedAtISO: string }

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Cache-Control', 'no-store');

  const KEY = 'borai:status';

  if (req.method === 'GET') {
    const data = (await kv.get(KEY)) as any;
    if (!data) {
      const init = { status: 'yes', updatedAtISO: new Date().toISOString() };
      await kv.set(KEY, init);
      return res.status(200).json(init);
    }
    return res.status(200).json(data);
  }

  if (req.method === 'POST') {
    try {
      const { action, secret } = req.body || {};
      const expected = process.env.SECRET_PIN;
      if (!expected) return res.status(500).json({ error: 'Server not configured' });
      if (secret !== expected) return res.status(401).json({ error: 'Unauthorized' });

      const cur = ((await kv.get(KEY)) as any) || { status: 'yes' };
      const now = new Date().toISOString();

      if (action === 'sleep') {
        const next = { status: 'no', bedISO: now, wakeISO: cur.wakeISO, updatedAtISO: now };
        await kv.set(KEY, next);
        return res.status(200).json(next);
      } else if (action === 'wake') {
        const next = { status: 'yes', wakeISO: now, bedISO: cur.bedISO, updatedAtISO: now };
        await kv.set(KEY, next);
        return res.status(200).json(next);
      } else {
        return res.status(400).json({ error: 'Invalid action' });
      }
    } catch (e:any) {
      return res.status(500).json({ error: 'Server error' });
    }
  }

  res.setHeader('Allow', 'GET, POST');
  return res.status(405).end('Method Not Allowed');
}
